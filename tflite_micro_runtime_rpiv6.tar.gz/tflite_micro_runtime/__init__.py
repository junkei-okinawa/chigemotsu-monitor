__version__ = '1.2.2'
__git_version__ = 'db140b11a43186bd4e495669199e9a5ca017a37b'
